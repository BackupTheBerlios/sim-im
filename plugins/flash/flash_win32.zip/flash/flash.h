/******************************************************************
***
***
***				FREE WINDOWLESS FLASH CONTROL
***
***					   by Makarov Igor
***
***		for questions and remarks mailto: mak_july@list.ru
***
***
*******************************************************************/

#if !defined(AFX_FLASH_H__03637834_4B49_478B_98FD_E7B146E19D99__INCLUDED_)
#define AFX_FLASH_H__03637834_4B49_478B_98FD_E7B146E19D99__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"


#endif // !defined(AFX_FLASH_H__03637834_4B49_478B_98FD_E7B146E19D99__INCLUDED_)
